async function load() {
  	internal_model = await tf.loadLayersModel('model.json');
	return internal_model;
};

function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
            document.getElementById("actualValue").innerHTML = "";
        };
};

function predict(model){
	const classif = ["Healthy", "Blight"];
	const omg = document.getElementById("uploadPreview");
	
		model.then(function (res) {
		    const example = tf.browser.fromPixels(omg);

    		const sample_image_reshaped = example.reshape([-1 , 256, 256, 3]);

		    const prediction = res.predict(sample_image_reshaped);
		    const value = prediction.dataSync()[0]
		    console.log(value)

		    var label = Math.round(value);
		    console.log(label)
		    if(label)
		    	document.getElementById("actualValue").innerHTML = classif[1];
		    else
		    	document.getElementById("actualValue").innerHTML = classif[0];

			}, function (err) {
		    
			});

}


const model = load();