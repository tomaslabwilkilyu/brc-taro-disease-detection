//import * as tf from '@tensorflow/tfjs';

async function load() {
  
  const internal_model = await tf.loadLayersModel('model.json');
  return internal_model;
  
};

function predict(model) {
  
  const img = new Image();
  
  img.src = 'sample.jpg';
  //const gantImage = document.getElementById('inputImage')
  const gantTensor = tf.browser.fromPixels(img);
  const prediction = model.predict(gantTensor);

  console.log(prediction);
  
  //const example = tf.fromPixels('sample.jpg');  // for example
  //alert(1);
  //
  //image = new Image(256,256);
  //image.src = 'sample.jpg';
  
  // Convert image to tensor and add batch dimension
 // tfTensor = tf.browser.fromPixels(image);

  //const pred = model.predict(tfTensor);
  //alert(1)
  


  //const example = tf.fromPixels(document.getElementById('inputImage'));  // for example
  //const prediction = model.predict(example);
  //alert(prediction);
  // first we get the value in the input field
  //const image = document.getElementById('inputImage');
  //const predictions = await model.classify(image);
  //const inputTensor = tf.tensor([userInput]);  // then convert to tensor
  //alert(1);
  // now lets make the prediction, we use .then because the model is a promise
  // (this is confusing as a Python user, but useful so check it out if interested)
  
  //model.then(model => {
  //  let result = model.predict(inputTensor);
  //  result = result.round().dataSync()[0];  // round prediction and get value
  //  alert(result ? "Healthy" : "Blite");
  //  alert(1);
  //});
};

const model = load();  // load model immediately to avoid delay when user clicks 'Predict'
